<?php

Route::group(['prefix' => 'v1', 'as' => 'api.', 'namespace' => 'Api\V1\Admin', 'middleware' => ['auth:sanctum']], function () {
    // Manage Tournament
    Route::post('manage-tournaments/media', 'ManageTournamentApiController@storeMedia')->name('manage-tournaments.storeMedia');
    Route::apiResource('manage-tournaments', 'ManageTournamentApiController');

    // Teams
    Route::post('teams/media', 'TeamsApiController@storeMedia')->name('teams.storeMedia');
    Route::apiResource('teams', 'TeamsApiController');

    // Tournament Battles
    Route::apiResource('tournament-battles', 'TournamentBattlesApiController');
});
