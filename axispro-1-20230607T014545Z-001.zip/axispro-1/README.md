# Axis Deployment
```
git clone https://github.com/hattorihanzo86/axispro.git
```
Copy the configuration
````
Run cp .env.example .env file to copy example file to .env
````
Then edit your .env file with DB credentials and other settings.

Install prerequisite
`````
composer install
`````
Running the migration file
`````
php artisan migrate --seed 
`````
`Notice: seed is important, because it will create the first admin user for you.`

Generating Keys
`````
php artisan key:generate
`````
Linking Storage last
`````
php artisan storage:link 
`````

Default Credentials

`````
email : admin@admin.com
password: password
`````