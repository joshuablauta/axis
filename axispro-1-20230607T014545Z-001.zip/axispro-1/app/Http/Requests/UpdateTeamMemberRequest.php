<?php

namespace App\Http\Requests;

use App\Models\TeamMember;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateTeamMemberRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('team_member_edit');
    }

    public function rules()
    {
        return [
            'team_id' => [
                'required',
                'integer',
            ],
        ];
    }
}
