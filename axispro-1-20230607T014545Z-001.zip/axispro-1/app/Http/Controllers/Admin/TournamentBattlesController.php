<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyTournamentBattleRequest;
use App\Http\Requests\StoreTournamentBattleRequest;
use App\Http\Requests\UpdateTournamentBattleRequest;
use App\Models\ManageTournament;
use App\Models\Team;
use App\Models\TournamentBattle;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TournamentBattlesController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('tournament_battle_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournamentBattles = TournamentBattle::with(['tournament', 'team_1', 'team_2'])->get();

        return view('admin.tournamentBattles.index', compact('tournamentBattles'));
    }

    public function create()
    {
        abort_if(Gate::denies('tournament_battle_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournaments = ManageTournament::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $team_1s = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $team_2s = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.tournamentBattles.create', compact('team_1s', 'team_2s', 'tournaments'));
    }

    public function store(StoreTournamentBattleRequest $request)
    {
        $tournamentBattle = TournamentBattle::create($request->all());

        return redirect()->route('admin.tournament-battles.index');
    }

    public function edit(TournamentBattle $tournamentBattle)
    {
        abort_if(Gate::denies('tournament_battle_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournaments = ManageTournament::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $team_1s = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $team_2s = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $tournamentBattle->load('tournament', 'team_1', 'team_2');

        return view('admin.tournamentBattles.edit', compact('team_1s', 'team_2s', 'tournamentBattle', 'tournaments'));
    }

    public function update(UpdateTournamentBattleRequest $request, TournamentBattle $tournamentBattle)
    {
        $tournamentBattle->update($request->all());

        return redirect()->route('admin.tournament-battles.index');
    }

    public function show(TournamentBattle $tournamentBattle)
    {
        abort_if(Gate::denies('tournament_battle_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournamentBattle->load('tournament', 'team_1', 'team_2');

        return view('admin.tournamentBattles.show', compact('tournamentBattle'));
    }

    public function destroy(TournamentBattle $tournamentBattle)
    {
        abort_if(Gate::denies('tournament_battle_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournamentBattle->delete();

        return back();
    }

    public function massDestroy(MassDestroyTournamentBattleRequest $request)
    {
        $tournamentBattles = TournamentBattle::find(request('ids'));

        foreach ($tournamentBattles as $tournamentBattle) {
            $tournamentBattle->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
