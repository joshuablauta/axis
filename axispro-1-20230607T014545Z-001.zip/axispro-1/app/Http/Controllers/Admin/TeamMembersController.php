<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyTeamMemberRequest;
use App\Http\Requests\StoreTeamMemberRequest;
use App\Http\Requests\UpdateTeamMemberRequest;
use App\Models\Team;
use App\Models\TeamMember;
use App\Models\User;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TeamMembersController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('team_member_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $teamMembers = TeamMember::with(['team', 'player'])->get();

        return view('admin.teamMembers.index', compact('teamMembers'));
    }

    public function create()
    {
        abort_if(Gate::denies('team_member_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $teams = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $players = User::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.teamMembers.create', compact('players', 'teams'));
    }

    public function store(StoreTeamMemberRequest $request)
    {
        $teamMember = TeamMember::create($request->all());

        return redirect()->route('admin.team-members.index');
    }

    public function edit(TeamMember $teamMember)
    {
        abort_if(Gate::denies('team_member_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $teams = Team::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $players = User::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $teamMember->load('team', 'player');

        return view('admin.teamMembers.edit', compact('players', 'teamMember', 'teams'));
    }

    public function update(UpdateTeamMemberRequest $request, TeamMember $teamMember)
    {
        $teamMember->update($request->all());

        return redirect()->route('admin.team-members.index');
    }

    public function show(TeamMember $teamMember)
    {
        abort_if(Gate::denies('team_member_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $teamMember->load('team', 'player');

        return view('admin.teamMembers.show', compact('teamMember'));
    }

    public function destroy(TeamMember $teamMember)
    {
        abort_if(Gate::denies('team_member_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $teamMember->delete();

        return back();
    }

    public function massDestroy(MassDestroyTeamMemberRequest $request)
    {
        $teamMembers = TeamMember::find(request('ids'));

        foreach ($teamMembers as $teamMember) {
            $teamMember->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
