<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyManageTournamentRequest;
use App\Http\Requests\StoreManageTournamentRequest;
use App\Http\Requests\UpdateManageTournamentRequest;
use App\Models\ManageTournament;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;

class ManageTournamentController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        abort_if(Gate::denies('manage_tournament_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $manageTournaments = ManageTournament::with(['media'])->get();

        return view('admin.manageTournaments.index', compact('manageTournaments'));
    }

    public function create()
    {
        abort_if(Gate::denies('manage_tournament_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.manageTournaments.create');
    }

    public function store(StoreManageTournamentRequest $request)
    {
        $manageTournament = ManageTournament::create($request->all());

        if ($request->input('banner', false)) {
            $manageTournament->addMedia(storage_path('tmp/uploads/' . basename($request->input('banner'))))->toMediaCollection('banner');
        }

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $manageTournament->id]);
        }

        return redirect()->route('admin.manage-tournaments.index');
    }

    public function edit(ManageTournament $manageTournament)
    {
        abort_if(Gate::denies('manage_tournament_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.manageTournaments.edit', compact('manageTournament'));
    }

    public function update(UpdateManageTournamentRequest $request, ManageTournament $manageTournament)
    {
        $manageTournament->update($request->all());

        if ($request->input('banner', false)) {
            if (! $manageTournament->banner || $request->input('banner') !== $manageTournament->banner->file_name) {
                if ($manageTournament->banner) {
                    $manageTournament->banner->delete();
                }
                $manageTournament->addMedia(storage_path('tmp/uploads/' . basename($request->input('banner'))))->toMediaCollection('banner');
            }
        } elseif ($manageTournament->banner) {
            $manageTournament->banner->delete();
        }

        return redirect()->route('admin.manage-tournaments.index');
    }

    public function show(ManageTournament $manageTournament)
    {
        abort_if(Gate::denies('manage_tournament_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.manageTournaments.show', compact('manageTournament'));
    }

    public function destroy(ManageTournament $manageTournament)
    {
        abort_if(Gate::denies('manage_tournament_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $manageTournament->delete();

        return back();
    }

    public function massDestroy(MassDestroyManageTournamentRequest $request)
    {
        $manageTournaments = ManageTournament::find(request('ids'));

        foreach ($manageTournaments as $manageTournament) {
            $manageTournament->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('manage_tournament_create') && Gate::denies('manage_tournament_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model         = new ManageTournament();
        $model->id     = $request->input('crud_id', 0);
        $model->exists = true;
        $media         = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }
}
