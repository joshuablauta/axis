<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTournamentBattleRequest;
use App\Http\Requests\UpdateTournamentBattleRequest;
use App\Http\Resources\Admin\TournamentBattleResource;
use App\Models\TournamentBattle;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TournamentBattlesApiController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('tournament_battle_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new TournamentBattleResource(TournamentBattle::with(['tournament', 'team_1', 'team_2'])->get());
    }

    public function store(StoreTournamentBattleRequest $request)
    {
        $tournamentBattle = TournamentBattle::create($request->all());

        return (new TournamentBattleResource($tournamentBattle))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(TournamentBattle $tournamentBattle)
    {
        abort_if(Gate::denies('tournament_battle_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new TournamentBattleResource($tournamentBattle->load(['tournament', 'team_1', 'team_2']));
    }

    public function update(UpdateTournamentBattleRequest $request, TournamentBattle $tournamentBattle)
    {
        $tournamentBattle->update($request->all());

        return (new TournamentBattleResource($tournamentBattle))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(TournamentBattle $tournamentBattle)
    {
        abort_if(Gate::denies('tournament_battle_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tournamentBattle->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
