<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreManageTournamentRequest;
use App\Http\Requests\UpdateManageTournamentRequest;
use App\Http\Resources\Admin\ManageTournamentResource;
use App\Models\ManageTournament;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ManageTournamentApiController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        abort_if(Gate::denies('manage_tournament_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new ManageTournamentResource(ManageTournament::all());
    }

    public function store(StoreManageTournamentRequest $request)
    {
        $manageTournament = ManageTournament::create($request->all());

        if ($request->input('banner', false)) {
            $manageTournament->addMedia(storage_path('tmp/uploads/' . basename($request->input('banner'))))->toMediaCollection('banner');
        }

        return (new ManageTournamentResource($manageTournament))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(ManageTournament $manageTournament)
    {
        abort_if(Gate::denies('manage_tournament_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new ManageTournamentResource($manageTournament);
    }

    public function update(UpdateManageTournamentRequest $request, ManageTournament $manageTournament)
    {
        $manageTournament->update($request->all());

        if ($request->input('banner', false)) {
            if (! $manageTournament->banner || $request->input('banner') !== $manageTournament->banner->file_name) {
                if ($manageTournament->banner) {
                    $manageTournament->banner->delete();
                }
                $manageTournament->addMedia(storage_path('tmp/uploads/' . basename($request->input('banner'))))->toMediaCollection('banner');
            }
        } elseif ($manageTournament->banner) {
            $manageTournament->banner->delete();
        }

        return (new ManageTournamentResource($manageTournament))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(ManageTournament $manageTournament)
    {
        abort_if(Gate::denies('manage_tournament_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $manageTournament->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
