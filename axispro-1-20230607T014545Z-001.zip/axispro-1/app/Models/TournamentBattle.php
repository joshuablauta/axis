<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TournamentBattle extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'tournament_battles';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public const STATUS_SELECT = [
        'eliminated' => 'Eliminated',
        'lose'       => 'Lose',
        'win'        => 'Win',
    ];

    protected $fillable = [
        'tournament_id',
        'team_1_id',
        'team_2_id',
        'status',
        'position',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function tournament()
    {
        return $this->belongsTo(ManageTournament::class, 'tournament_id');
    }

    public function team_1()
    {
        return $this->belongsTo(Team::class, 'team_1_id');
    }

    public function team_2()
    {
        return $this->belongsTo(Team::class, 'team_2_id');
    }
}
