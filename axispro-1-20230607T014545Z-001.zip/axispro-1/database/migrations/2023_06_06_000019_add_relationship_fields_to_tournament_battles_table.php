<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToTournamentBattlesTable extends Migration
{
    public function up()
    {
        Schema::table('tournament_battles', function (Blueprint $table) {
            $table->unsignedBigInteger('tournament_id')->nullable();
            $table->foreign('tournament_id', 'tournament_fk_8591523')->references('id')->on('manage_tournaments');
            $table->unsignedBigInteger('team_1_id')->nullable();
            $table->foreign('team_1_id', 'team_1_fk_8591507')->references('id')->on('teams');
            $table->unsignedBigInteger('team_2_id')->nullable();
            $table->foreign('team_2_id', 'team_2_fk_8591524')->references('id')->on('teams');
        });
    }
}
