@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.teamMember.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.team-members.update", [$teamMember->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="team_id">{{ trans('cruds.teamMember.fields.team') }}</label>
                <select class="form-control select2 {{ $errors->has('team') ? 'is-invalid' : '' }}" name="team_id" id="team_id" required>
                    @foreach($teams as $id => $entry)
                        <option value="{{ $id }}" {{ (old('team_id') ? old('team_id') : $teamMember->team->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('team'))
                    <div class="invalid-feedback">
                        {{ $errors->first('team') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.teamMember.fields.team_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="player_id">{{ trans('cruds.teamMember.fields.player') }}</label>
                <select class="form-control select2 {{ $errors->has('player') ? 'is-invalid' : '' }}" name="player_id" id="player_id">
                    @foreach($players as $id => $entry)
                        <option value="{{ $id }}" {{ (old('player_id') ? old('player_id') : $teamMember->player->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('player'))
                    <div class="invalid-feedback">
                        {{ $errors->first('player') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.teamMember.fields.player_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection