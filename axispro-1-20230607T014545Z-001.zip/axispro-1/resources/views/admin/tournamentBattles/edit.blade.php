@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.tournamentBattle.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.tournament-battles.update", [$tournamentBattle->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label for="tournament_id">{{ trans('cruds.tournamentBattle.fields.tournament') }}</label>
                <select class="form-control select2 {{ $errors->has('tournament') ? 'is-invalid' : '' }}" name="tournament_id" id="tournament_id">
                    @foreach($tournaments as $id => $entry)
                        <option value="{{ $id }}" {{ (old('tournament_id') ? old('tournament_id') : $tournamentBattle->tournament->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('tournament'))
                    <div class="invalid-feedback">
                        {{ $errors->first('tournament') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.tournamentBattle.fields.tournament_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="team_1_id">{{ trans('cruds.tournamentBattle.fields.team_1') }}</label>
                <select class="form-control select2 {{ $errors->has('team_1') ? 'is-invalid' : '' }}" name="team_1_id" id="team_1_id">
                    @foreach($team_1s as $id => $entry)
                        <option value="{{ $id }}" {{ (old('team_1_id') ? old('team_1_id') : $tournamentBattle->team_1->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('team_1'))
                    <div class="invalid-feedback">
                        {{ $errors->first('team_1') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.tournamentBattle.fields.team_1_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="team_2_id">{{ trans('cruds.tournamentBattle.fields.team_2') }}</label>
                <select class="form-control select2 {{ $errors->has('team_2') ? 'is-invalid' : '' }}" name="team_2_id" id="team_2_id">
                    @foreach($team_2s as $id => $entry)
                        <option value="{{ $id }}" {{ (old('team_2_id') ? old('team_2_id') : $tournamentBattle->team_2->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('team_2'))
                    <div class="invalid-feedback">
                        {{ $errors->first('team_2') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.tournamentBattle.fields.team_2_helper') }}</span>
            </div>
            <div class="form-group">
                <label>{{ trans('cruds.tournamentBattle.fields.status') }}</label>
                <select class="form-control {{ $errors->has('status') ? 'is-invalid' : '' }}" name="status" id="status">
                    <option value disabled {{ old('status', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                    @foreach(App\Models\TournamentBattle::STATUS_SELECT as $key => $label)
                        <option value="{{ $key }}" {{ old('status', $tournamentBattle->status) === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
                @if($errors->has('status'))
                    <div class="invalid-feedback">
                        {{ $errors->first('status') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.tournamentBattle.fields.status_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="position">{{ trans('cruds.tournamentBattle.fields.position') }}</label>
                <input class="form-control {{ $errors->has('position') ? 'is-invalid' : '' }}" type="number" name="position" id="position" value="{{ old('position', $tournamentBattle->position) }}" step="1">
                @if($errors->has('position'))
                    <div class="invalid-feedback">
                        {{ $errors->first('position') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.tournamentBattle.fields.position_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection