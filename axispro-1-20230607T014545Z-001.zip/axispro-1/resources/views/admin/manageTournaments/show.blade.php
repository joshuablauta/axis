@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.manageTournament.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.manage-tournaments.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.id') }}
                        </th>
                        <td>
                            {{ $manageTournament->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.name') }}
                        </th>
                        <td>
                            {{ $manageTournament->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.description') }}
                        </th>
                        <td>
                            {!! $manageTournament->description !!}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.location') }}
                        </th>
                        <td>
                            {{ $manageTournament->location }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.date') }}
                        </th>
                        <td>
                            {{ $manageTournament->date }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.manageTournament.fields.banner') }}
                        </th>
                        <td>
                            @if($manageTournament->banner)
                                <a href="{{ $manageTournament->banner->getUrl() }}" target="_blank" style="display: inline-block">
                                    <img src="{{ $manageTournament->banner->getUrl('thumb') }}">
                                </a>
                            @endif
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.manage-tournaments.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
        </div>
    </div>
</div>



@endsection