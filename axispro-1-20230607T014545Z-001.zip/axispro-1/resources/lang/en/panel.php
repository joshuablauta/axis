<?php

return [
    'site_title' => 'axispro',

];
